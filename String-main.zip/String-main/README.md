these are some codes i practiced on string u can check and use them freely and i hope it helps 
